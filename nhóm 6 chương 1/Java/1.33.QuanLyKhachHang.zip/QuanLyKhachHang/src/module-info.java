/**
 * 
 */
/**
 * 
 */
module QuanLyKhachHang {
}