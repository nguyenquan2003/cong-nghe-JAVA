package code;

public interface XetKhenThuong {
    public double tinhKhenThuong();
}
